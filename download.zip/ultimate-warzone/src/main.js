import { Game } from './core/Game.js';

window.onload = () => {
    const game = new Game();
    game.initialize();
};
