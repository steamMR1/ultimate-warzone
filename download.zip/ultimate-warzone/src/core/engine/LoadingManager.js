class LoadingManager {
    constructor() {
        this.progress = 0;
        this.totalAssets = 0;
        this.loadedAssets = 0;
        this.loadingScreen = document.getElementById('loading-screen');
        this.progressBar = document.querySelector('.loading-progress');
    }

    startLoading() {
        this.loadAssets();
        this.updateProgress();
        this.checkLoadingComplete();
    }

    loadAssets() {
        Promise.all([
            this.loadModels(),
            this.loadTextures(),
            this.loadSounds()
        ]).then(() => {
            this.hideLoadingScreen();
            this.startGame();
        });
    }

    hideLoadingScreen() {
        this.loadingScreen.style.display = 'none';
        document.getElementById('game-container').style.display = 'block';
    }
}
