class GameEngine {
    constructor() {
        this.isLoaded = false;
        this.init();
    }

    init() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('webgl2');
        this.setupRendering();
        this.isLoaded = true;
    }

    start() {
        if (this.isLoaded) {
            document.getElementById('loading-screen').style.display = 'none';
            this.gameLoop();
        }
    }

    gameLoop() {
        requestAnimationFrame(() => this.gameLoop());
        this.update();
        this.render();
    }
}
