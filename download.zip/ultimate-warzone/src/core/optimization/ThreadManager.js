class ThreadManager {
    constructor() {
        this.workers = new Map();
        this.maxWorkers = navigator.hardwareConcurrency;
        this.tasks = new Queue();
        
        this.threadAllocation = {
            physics: 2,
            ai: 2,
            rendering: 1,
            networking: 1
        };
    }

    spawnWorker(type) {
        const worker = new Worker(`workers/${type}Worker.js`);
        this.workers.set(type, worker);
        this.initializeWorker(worker, type);
    }
}
