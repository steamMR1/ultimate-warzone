class VehicleSystem {
    constructor() {
        this.vehicles = new Map();
        this.spawnPoints = [];
        
        this.vehicleTypes = {
            GROUND: ['SUV', 'TRUCK', 'ATV'],
            AIR: ['HELICOPTER'],
            WATER: ['BOAT']
        };
    }

    spawnVehicle(type, location) {
        const vehicle = this.createVehicle(type);
        return this.placeVehicle(vehicle, location);
    }
}
