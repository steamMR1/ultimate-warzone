class MovementSystem {
    constructor() {
        this.moveSpeed = {
            walk: 5,
            run: 8,
            sprint: 12,
            crouch: 3
        };
        
        this.states = {
            STANDING: 'stand',
            CROUCHING: 'crouch',
            PRONE: 'prone'
        };
    }

    updatePlayerMovement(player, input) {
        const state = this.getCurrentState(player);
        return this.calculateNewPosition(player, input, state);
    }
}
