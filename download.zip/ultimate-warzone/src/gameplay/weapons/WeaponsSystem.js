class WeaponSystem {
    constructor() {
        this.weapons = new Map();
        this.activeWeapon = null;
        this.loadouts = [];
        
        this.weaponTypes = {
            AR: 'ASSAULT_RIFLE',
            SMG: 'SUBMACHINE_GUN',
            SNIPER: 'SNIPER_RIFLE',
            LMG: 'LIGHT_MACHINE_GUN',
            PISTOL: 'HANDGUN'
        };
    }

    initializeWeapons() {
        this.loadWeaponData();
        this.setupAttachments();
        this.initializeAmmoTypes();
    }
}
