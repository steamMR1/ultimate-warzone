class ControlSettings {
    constructor() {
        this.sensitivity = {
            mouse: 5.0,
            ads: 1.0,
            gamepad: 3.0
        };
        
        this.bindings = {
            keyboard: new Map(),
            mouse: new Map(),
            gamepad: new Map()
        };
    }

    updateControls() {
        this.applyBindings();
        this.updateSensitivity();
        this.saveControlProfile();
    }
}
