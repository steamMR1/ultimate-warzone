class UIManager {
    constructor() {
        this.elements = new Map();
        this.activeMenus = [];
        
        this.layers = {
            HUD: 'hud',
            MENU: 'menu',
            OVERLAY: 'overlay'
        };
    }

    updateUI(gameState) {
        this.refreshHUD(gameState);
        this.handleMenus();
        this.updateOverlays();
    }
}
