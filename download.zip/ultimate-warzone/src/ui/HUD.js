class HUD {
    constructor() {
        this.components = {
            minimap: null,
            health: null,
            ammo: null,
            compass: null
        };
        
        this.visibility = {
            enabled: true,
            opacity: 1.0
        };
    }

    render(playerState) {
        this.updateMinimap(playerState.position);
        this.updateStats(playerState.stats);
        this.updateCompass(playerState.rotation);
    }
}
