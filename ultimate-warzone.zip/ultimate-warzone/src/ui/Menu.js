class Menu {
    constructor() {
        this.currentMenu = 'MAIN';
        this.history = [];
        
        this.menus = {
            MAIN: 'mainMenu',
            SETTINGS: 'settings',
            LOADOUT: 'loadout'
        };
    }

    navigate(menuName) {
        this.saveHistory();
        this.loadMenu(menuName);
        this.updateDisplay();
    }
}
