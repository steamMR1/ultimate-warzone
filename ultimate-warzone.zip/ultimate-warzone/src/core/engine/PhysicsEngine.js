class PhysicsEngine {
    constructor() {
        this.world = new CANNON.World();
        this.gravity = -9.81;
        this.bodies = new Map();
        
        this.collisionGroups = {
            PLAYERS: 1,
            TERRAIN: 2,
            VEHICLES: 4,
            PROJECTILES: 8
        };
    }

    initialize() {
        this.world.gravity.set(0, this.gravity, 0);
        this.world.broadphase = new CANNON.SAPBroadphase(this.world);
        this.world.solver.iterations = 10;
    }
}
