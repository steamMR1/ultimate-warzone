class MatchMaking {
    constructor() {
        this.regions = ['EU', 'NA', 'ASIA', 'OCE'];
        this.modes = ['BR_SOLO', 'BR_DUOS', 'BR_TRIOS', 'BR_QUADS'];
        this.queue = new Map();
        this.matchSize = 150;
        
        this.matchmakingRules = {
            skillBased: true,
            maxPing: 100,
            minPlayers: 140
        };
    }

    findMatch(player) {
        const region = this.determineRegion(player);
        const mode = player.selectedMode;
        return this.queuePlayer(player, region, mode);
    }
}
