class Attachments {
    constructor() {
        this.slots = {
            MUZZLE: 'muzzle',
            BARREL: 'barrel',
            LASER: 'laser',
            OPTIC: 'optic',
            STOCK: 'stock',
            UNDERBARREL: 'underbarrel',
            AMMUNITION: 'ammunition',
            GRIP: 'grip',
            PERK: 'perk'
        };

        this.attachments = {
            muzzle: {
                MONOLITHIC: {
                    name: 'Monolithic Suppressor',
                    stats: {
                        damage_range: 7.5,
                        sound_suppression: true,
                        ads_speed: -1
                    }
                },
                TACTICAL: {
                    name: 'Tactical Suppressor',
                    stats: {
                        sound_suppression: true,
                        ads_speed: -0.5
                    }
                },
                COMPENSATOR: {
                    name: 'Compensator',
                    stats: {
                        recoil_control: 12
                    }
                },
                MUZZLE_BRAKE: {
                    name: 'Muzzle Brake',
                    stats: {
                        recoil_stabilization: 15
                    }
                }
            },

            barrel: {
                TEMPUS_MARKSMAN: {
                    name: 'Tempus Marksman',
                    stats: {
                        damage_range: 10,
                        recoil_control: 8,
                        bullet_velocity: 15,
                        ads_speed: -3
                    }
                },
                CORVUS_CUSTOM: {
                    name: 'Corvus Custom Marksman',
                    stats: {
                        damage_range: 8,
                        recoil_control: 6,
                        bullet_velocity: 12,
                        ads_speed: -2
                    }
                }
            },

            laser: {
                TAC_LASER: {
                    name: 'Tac Laser',
                    stats: {
                        ads_speed: 4,
                        aiming_stability: 8,
                        visible_laser: true
                    }
                },
                FIVE_MW: {
                    name: '5mW Laser',
                    stats: {
                        hip_fire_accuracy: 15,
                        sprint_to_fire: 5,
                        visible_laser: true
                    }
                }
            },

            optic: {
                VLK_3X: {
                    name: 'VLK 3.0x Optic',
                    stats: {
                        magnification: 3,
                        recoil_control: 2
                    }
                },
                GI_MINI: {
                    name: 'G.I. Mini Reflex',
                    stats: {
                        magnification: 1.5,
                        ads_speed: -0.5
                    }
                }
            },

            stock: {
                NO_STOCK: {
                    name: 'No Stock',
                    stats: {
                        movement_speed: 4,
                        ads_speed: 4,
                        recoil_control: -20
                    }
                },
                CQB: {
                    name: 'CQB Stock',
                    stats: {
                        ads_speed: 2,
                        movement_speed: 2
                    }
                }
            },

            underbarrel: {
                COMMANDO: {
                    name: 'Commando Foregrip',
                    stats: {
                        recoil_stabilization: 15,
                        movement_speed: -1
                    }
                },
                MERC: {
                    name: 'Merc Foregrip',
                    stats: {
                        recoil_control: 17,
                        hip_fire_accuracy: 15,
                        movement_speed: -1
                    }
                }
            },

            ammunition: {
                EXTENDED_MAG: {
                    name: '50 Round Mags',
                    stats: {
                        magazine_capacity: 50,
                        movement_speed: -1
                    }
                },
                STOPPING_POWER: {
                    name: 'Stopping Power Rounds',
                    stats: {
                        damage: 40,
                        magazine_capacity: -50
                    }
                }
            },

            grip: {
                STIPPLED: {
                    name: 'Stippled Grip Tape',
                    stats: {
                        ads_speed: 2,
                        sprint_to_fire: 2,
                        aiming_stability: -4
                    }
                },
                GRANULATED: {
                    name: 'Granulated Grip Tape',
                    stats: {
                        aiming_stability: 12,
                        ads_speed: -1
                    }
                }
            },

            perk: {
                SLEIGHT_OF_HAND: {
                    name: 'Sleight of Hand',
                    stats: {
                        reload_speed: 30
                    }
                },
                FMJ: {
                    name: 'FMJ',
                    stats: {
                        penetration: 30
                    }
                }
            }
        };
    }

    applyAttachment(weapon, slot, attachmentName) {
        const attachment = this.attachments[slot][attachmentName];
        if (attachment) {
            this.updateWeaponStats(weapon, attachment.stats);
            return true;
        }
        return false;
    }

    updateWeaponStats(weapon, stats) {
        Object.keys(stats).forEach(stat => {
            weapon.stats[stat] += stats[stat];
        });
    }
}
