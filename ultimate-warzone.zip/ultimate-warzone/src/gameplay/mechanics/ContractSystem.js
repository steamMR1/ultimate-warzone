class ContractSystem {
    constructor() {
        this.activeContracts = new Map();
        this.contractTypes = {
            BOUNTY: 'bounty',
            SCAVENGER: 'scavenger',
            RECON: 'recon'
        };
        
        this.rewards = {
            cash: 1000,
            xp: 500
        };
    }

    startContract(player, type) {
        const contract = this.generateContract(type);
        return this.assignContract(player, contract);
    }
}
