class SettingsManager {
    constructor() {
        this.currentProfile = 'default';
        this.settings = new Map();
        
        this.categories = {
            GRAPHICS: 'graphics',
            AUDIO: 'audio',
            CONTROLS: 'controls'
        };
    }

    loadSettings() {
        this.fetchUserSettings();
        this.applySettings();
        this.saveToLocal();
    }
}
